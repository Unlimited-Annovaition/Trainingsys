CREATE PROCEDURE sp_DeleteEnrollment
@EnrollmentId INT
AS
BEGIN
    DELETE FROM Enrollments WHERE EnrollmentId = @EnrollmentId;
END;
go


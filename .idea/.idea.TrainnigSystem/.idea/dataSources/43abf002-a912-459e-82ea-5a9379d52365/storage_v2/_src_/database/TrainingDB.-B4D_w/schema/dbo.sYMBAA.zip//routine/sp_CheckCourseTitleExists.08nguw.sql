CREATE procedure sp_CheckCourseTitleExists
    @Title NVARCHAR(150)
AS 
    BEGIN 
        IF EXISTS(SELECT 1 FROM  Courses where Title = @Title)
            select 1 AS IsExists
        ELSE
            select 0 AS IsExists
    end
go


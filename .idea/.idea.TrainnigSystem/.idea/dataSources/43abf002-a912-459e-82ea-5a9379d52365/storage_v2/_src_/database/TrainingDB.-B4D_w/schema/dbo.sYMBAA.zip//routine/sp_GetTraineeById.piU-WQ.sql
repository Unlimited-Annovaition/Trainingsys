CREATE PROCEDURE sp_GetTraineeById
@TraineeId INT
AS
BEGIN
    SELECT * FROM Trainees WHERE TraineeId = @TraineeId;
END;
go


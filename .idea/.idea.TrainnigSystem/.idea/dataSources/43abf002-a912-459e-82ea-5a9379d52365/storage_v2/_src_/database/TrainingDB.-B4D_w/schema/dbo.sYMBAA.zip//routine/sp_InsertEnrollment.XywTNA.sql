CREATE PROCEDURE sp_InsertEnrollment
    @CourseId INT,
    @TraineeId INT,
    @EnrollmentDate DATETIME
AS
BEGIN
    INSERT INTO Enrollments (CourseId, TraineeId, EnrollmentDate)
    VALUES (@CourseId, @TraineeId, @EnrollmentDate);
END;
go


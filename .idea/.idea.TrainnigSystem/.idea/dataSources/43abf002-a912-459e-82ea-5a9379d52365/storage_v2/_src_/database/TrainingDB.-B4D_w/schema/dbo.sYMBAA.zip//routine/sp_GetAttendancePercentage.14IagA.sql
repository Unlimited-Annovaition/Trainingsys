CREATE PROCEDURE sp_GetAttendancePercentage
@EnrollmentId INT
AS
BEGIN
    SELECT
        EnrollmentId,
        COUNT(*) AS TotalSessions, 
        SUM(CAST(Status AS INT)) AS AttendedSessions, 
        ISNULL((SUM(CAST(Status AS INT)) * 100.0) / NULLIF(COUNT(*), 0), 0) AS AttendancePercentage
    FROM Attendance
    WHERE EnrollmentId = @EnrollmentId
    GROUP BY EnrollmentId;
END;
go


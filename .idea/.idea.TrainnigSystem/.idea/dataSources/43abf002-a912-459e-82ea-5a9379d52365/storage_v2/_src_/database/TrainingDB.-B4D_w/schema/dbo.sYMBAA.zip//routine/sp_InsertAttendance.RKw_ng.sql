CREATE PROCEDURE sp_InsertAttendance
    @EnrollmentId INT,
    @Date DATE,
    @Status BIT
AS
BEGIN
    INSERT INTO Attendance (EnrollmentId, Date, Status)
    VALUES (@EnrollmentId, @Date, @Status);
END;
go


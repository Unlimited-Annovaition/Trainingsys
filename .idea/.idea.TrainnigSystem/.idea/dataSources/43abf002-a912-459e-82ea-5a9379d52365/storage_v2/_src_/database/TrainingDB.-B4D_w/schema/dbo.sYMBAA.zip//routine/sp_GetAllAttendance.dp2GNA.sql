CREATE PROCEDURE sp_GetAllAttendance
AS
BEGIN
    SELECT * FROM Attendance;
END;
go


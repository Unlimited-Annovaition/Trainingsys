CREATE PROCEDURE sp_UpdateEnrollment
    @EnrollmentId INT,
    @CourseId INT,
    @TraineeId INT,
    @EnrollmentDate DATETIME,
    @Grade FLOAT,
    @IsPassed BIT
AS
BEGIN
    UPDATE Enrollments
    SET CourseId = @CourseId, TraineeId = @TraineeId, EnrollmentDate = @EnrollmentDate, Grade = @Grade, IsPassed = @IsPassed
    WHERE EnrollmentId = @EnrollmentId;
END;
go


CREATE PROCEDURE sp_GetAllTrainers
AS
BEGIN
    SELECT * FROM Trainers;
END;
go


CREATE PROCEDURE sp_InsertTrainer
    @FullName NVARCHAR(100),
    @Specialization NVARCHAR(100),
    @UserId INT
AS
BEGIN
    INSERT INTO Trainers (FullName, Specialization, UserId)
    VALUES (@FullName, @Specialization, @UserId);
END;
go


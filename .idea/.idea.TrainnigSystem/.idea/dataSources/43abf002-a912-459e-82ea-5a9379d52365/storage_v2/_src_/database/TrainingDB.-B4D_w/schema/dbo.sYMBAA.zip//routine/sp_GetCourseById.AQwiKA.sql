CREATE PROCEDURE sp_GetCourseById
@CourseId INT
AS 
BEGIN 
    select * from Courses Where CourseId = @CourseId
end;
go


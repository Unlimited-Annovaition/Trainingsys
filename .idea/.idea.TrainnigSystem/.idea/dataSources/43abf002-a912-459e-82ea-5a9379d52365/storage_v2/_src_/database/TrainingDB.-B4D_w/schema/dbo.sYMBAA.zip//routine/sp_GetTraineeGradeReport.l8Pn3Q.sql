Create Procedure sp_GetTraineeGradeReport
@TraineeId INT,
@CourseId INT
AS
    BEGIN 
        Select 
            t.Fullname AS TraineeName,
            c.Title AS CourseTitle,
            g.Score,
            g.Evaluation 
        FROM Grades g
                 INNER JOIN Enrollments e ON g.EnrollmentId = e.EnrollmentId
                 INNER JOIN Trainees t ON e.TraineeId = t.TraineeId
                 INNER JOIN Courses c ON e.CourseId = c.CourseId
        WHERE e.TraineeId = @TraineeId AND e.CourseId = @CourseId;
    END;
go


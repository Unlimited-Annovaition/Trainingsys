CREATE  PROCEDURE sp_GetTraineesByCourseId
@CourseId INT
AS
BEGIN
    SELECT T.* FROM Trainees T
                        INNER JOIN Enrollments E ON T.TraineeID = E.TraineeId
    WHERE E.CourseId = @CourseId;
END;
go


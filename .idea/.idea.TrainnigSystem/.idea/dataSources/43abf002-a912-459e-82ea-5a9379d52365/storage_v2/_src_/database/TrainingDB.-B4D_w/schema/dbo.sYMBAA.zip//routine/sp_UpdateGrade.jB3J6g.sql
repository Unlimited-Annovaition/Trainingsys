CREATE PROCEDURE sp_UpdateGrade
    @GradeId INT,
    @EnrollmentId INT,
    @Score FLOAT,
    @Evaluation NVARCHAR(20)
AS
BEGIN
    UPDATE Grades
    SET EnrollmentId = @EnrollmentId, Score = @Score, Evaluation = @Evaluation
    WHERE GradeId = @GradeId;
END;
go


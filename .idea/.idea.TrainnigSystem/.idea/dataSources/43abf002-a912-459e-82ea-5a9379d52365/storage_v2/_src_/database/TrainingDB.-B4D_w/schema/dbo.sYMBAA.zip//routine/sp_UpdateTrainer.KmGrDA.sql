CREATE PROCEDURE sp_UpdateTrainer
    @TrainerId INT,
    @FullName NVARCHAR(100),
    @Specialization NVARCHAR(100)
AS
BEGIN
    UPDATE Trainers
    SET FullName = @FullName, Specialization = @Specialization
    WHERE TrainerId = @TrainerId;
END;
go


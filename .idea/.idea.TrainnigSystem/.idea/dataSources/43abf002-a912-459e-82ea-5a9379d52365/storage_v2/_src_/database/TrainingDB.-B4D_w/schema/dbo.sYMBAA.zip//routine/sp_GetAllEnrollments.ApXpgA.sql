CREATE PROCEDURE sp_GetAllEnrollments
AS
BEGIN
    SELECT * FROM Enrollments;
END;
go


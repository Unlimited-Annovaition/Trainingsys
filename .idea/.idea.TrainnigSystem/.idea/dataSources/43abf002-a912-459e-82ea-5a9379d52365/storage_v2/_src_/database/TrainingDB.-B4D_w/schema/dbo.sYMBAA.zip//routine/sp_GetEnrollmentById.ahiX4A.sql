CREATE PROCEDURE sp_GetEnrollmentById
@EnrollmentId INT
AS
BEGIN
    SELECT * FROM Enrollments WHERE EnrollmentId = @EnrollmentId;
END;
go


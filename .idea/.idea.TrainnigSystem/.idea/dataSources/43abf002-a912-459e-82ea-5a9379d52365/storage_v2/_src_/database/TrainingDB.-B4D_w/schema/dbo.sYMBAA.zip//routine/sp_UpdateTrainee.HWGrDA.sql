CREATE  PROCEDURE sp_UpdateTrainee
    @TraineeId INT,
    @FullName NVARCHAR(100),
    @PhoneNumber NVARCHAR(20)
AS
BEGIN
    UPDATE Trainees
    SET FullName = @FullName,
        PhoneNumber = @PhoneNumber
    WHERE TraineeId = @TraineeId;
END;
go


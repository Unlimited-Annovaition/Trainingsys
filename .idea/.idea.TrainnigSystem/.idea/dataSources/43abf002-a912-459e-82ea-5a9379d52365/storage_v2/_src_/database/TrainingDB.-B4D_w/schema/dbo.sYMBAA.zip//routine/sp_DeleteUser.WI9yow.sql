CREATE PROCEDURE sp_DeleteUser
@UserId INT
AS
BEGIN
    DELETE FROM Users WHERE UserId = @UserId;
END;
go


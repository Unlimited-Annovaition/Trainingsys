CREATE PROCEDURE sp_InsertGrade
    @EnrollmentId INT,
    @Score FLOAT,
    @Evaluation NVARCHAR(20)
AS
BEGIN
    INSERT INTO Grades (EnrollmentId, Score, Evaluation)
    VALUES (@EnrollmentId, @Score, @Evaluation);
END;
go


CREATE PROCEDURE sp_IsCourseFull
@CourseId INT
AS
BEGIN
    DECLARE @Capacity INT;
    DECLARE @CurrentEnrolled INT;

    SELECT @Capacity = Capacity FROM Courses WHERE CourseId = @CourseId;

    SELECT @CurrentEnrolled = COUNT(*) FROM Enrollments WHERE CourseId = @CourseId;

    IF (@CurrentEnrolled >= @Capacity)
        SELECT 1 AS IsFull;
    ELSE
        SELECT 0 AS IsFull;
END;
go


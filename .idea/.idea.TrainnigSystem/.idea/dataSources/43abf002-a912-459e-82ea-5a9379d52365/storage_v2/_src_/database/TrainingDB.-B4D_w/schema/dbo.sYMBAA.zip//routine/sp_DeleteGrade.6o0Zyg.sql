CREATE PROCEDURE sp_DeleteGrade
@GradeId INT
AS
BEGIN
    DELETE FROM Grades WHERE GradeId = @GradeId;
END;
go


CREATE PROCEDURE sp_GetAllCourses
AS 
BEGIN 
    SELECT * from Courses;
end;
go


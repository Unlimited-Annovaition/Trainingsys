CREATE PROCEDURE sp_CheckEmailExists
@Email NVARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Users WHERE Email = @Email)
        SELECT 1 AS IsExists;
    ELSE
        SELECT 0 AS IsExists;
END;
go


Create Procedure sp_GetTrainees_SearchAndPaginate
    @SearchItem nvarchar(100) = null,
    @pageNumber INT = 1,
    @pageSize INT = 10
    AS
BEGIN
    SELECT
        t.TraineeId,
        t.FullName,
        t.PhoneNumber,
        u.Email,
        u.Username
    FROM Trainees t
             INNER JOIN Users u ON t.UserId = u.UserId
    WHERE
        (@SearchItem IS NULL OR @SearchItem = ''
            OR t.FullName LIKE '%' + @SearchItem + '%'
            OR u.Email LIKE '%' + @SearchItem + '%')
    ORDER BY t.TraineeId
    OFFSET (@PageNumber - 1) * @PageSize ROWS
        FETCH NEXT @PageSize ROWS ONLY;
end
go


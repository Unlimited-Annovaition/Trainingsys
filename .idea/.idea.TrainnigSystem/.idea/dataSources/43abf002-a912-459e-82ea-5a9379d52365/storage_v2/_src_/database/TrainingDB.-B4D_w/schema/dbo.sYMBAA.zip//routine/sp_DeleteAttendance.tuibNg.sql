CREATE PROCEDURE sp_DeleteAttendance
@AttendanceId INT
AS
BEGIN
    DELETE FROM Attendance WHERE AttendanceId = @AttendanceId;
END;
go


Create PROCEDURE sp_InsertUser
    @FirstName NVARCHAR(100),
    @PasswordHash NVARCHAR(MAX),
    @Email NVARCHAR(100),
    @RoleId INT
AS
BEGIN
    INSERT INTO Users (Username, PasswordHash, Email, RoleId)
    VALUES (@FirstName, @PasswordHash, @Email, @RoleId);

    SELECT CAST(SCOPE_IDENTITY() AS INT);
END;
go


CREATE PROCEDURE sp_GetUserByEmail
@Email NVARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT * FROM Users
    WHERE Email = @Email;
END
go


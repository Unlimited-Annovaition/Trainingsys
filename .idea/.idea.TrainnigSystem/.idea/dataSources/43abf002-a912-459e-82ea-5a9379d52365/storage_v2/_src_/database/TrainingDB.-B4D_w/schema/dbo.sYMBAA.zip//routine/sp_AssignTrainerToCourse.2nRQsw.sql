CREATE PROCEDURE sp_AssignTrainerToCourse
    @CourseId INT,
    @TrainerId INT
AS
BEGIN
    UPDATE Courses
    SET TrainerId = @TrainerId
    WHERE CourseId = @CourseId;
END;
go


CREATE PROCEDURE sp_DeleteTrainee
@TraineeId INT
AS
BEGIN
    DELETE FROM Trainees WHERE TraineeId = @TraineeId;
END;
go


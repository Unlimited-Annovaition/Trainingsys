CREATE PROCEDURE sp_CreateCourse
@Title NVARCHAR(150),
@Description NVARCHAR(MAX),
@Capacity INT,
@StartDate DATE,
@EndDate DATE,
@TrainerId INT = NULL
    AS 
BEGIN
    INSERT INTO Courses (Title, Description, Capacity, StartDate, EndDate, TrainerId)
    VALUES (@Title, @Description, @Capacity, @StartDate, @EndDate, @TrainerId);
end
go


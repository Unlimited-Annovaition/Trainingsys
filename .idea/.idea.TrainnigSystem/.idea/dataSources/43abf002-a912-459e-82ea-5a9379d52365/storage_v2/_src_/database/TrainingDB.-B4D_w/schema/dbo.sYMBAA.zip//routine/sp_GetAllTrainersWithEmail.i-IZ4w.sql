Create PROCEDURE sp_GetAllTrainersWithEmail
As
Begin
    SELECT
        T.TrainerId,
        T.FullName,
        T.specialization,
        U.Email
    from Trainers AS T
             INNER JOIN Users AS U ON T.UserId = U.UserID
end
go


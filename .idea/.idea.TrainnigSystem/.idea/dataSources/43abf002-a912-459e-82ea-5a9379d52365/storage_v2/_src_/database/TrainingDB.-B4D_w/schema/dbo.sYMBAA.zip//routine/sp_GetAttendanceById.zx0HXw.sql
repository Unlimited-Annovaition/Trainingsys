CREATE PROCEDURE sp_GetAttendanceById
@AttendanceId INT
AS
BEGIN
    SELECT * FROM Attendance WHERE AttendanceId = @AttendanceId;
END;
go


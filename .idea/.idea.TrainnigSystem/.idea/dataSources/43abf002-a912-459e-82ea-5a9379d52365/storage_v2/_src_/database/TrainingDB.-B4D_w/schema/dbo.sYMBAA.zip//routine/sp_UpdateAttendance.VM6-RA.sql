CREATE PROCEDURE sp_UpdateAttendance
    @AttendanceId INT,
    @EnrollmentId INT,
    @Date DATE,
    @Status BIT
AS
BEGIN
    UPDATE Attendance
    SET EnrollmentId = @EnrollmentId, Date = @Date, Status = @Status
    WHERE AttendanceId = @AttendanceId;
END;
go


CREATE PROCEDURE sp_DeleteTrainer
@TrainerId INT
AS
BEGIN
    DELETE FROM Trainers WHERE TrainerId = @TrainerId;
END;
go


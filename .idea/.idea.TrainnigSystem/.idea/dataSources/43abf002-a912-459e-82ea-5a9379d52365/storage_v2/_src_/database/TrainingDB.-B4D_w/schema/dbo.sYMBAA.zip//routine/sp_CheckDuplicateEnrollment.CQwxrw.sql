CREATE PROCEDURE sp_CheckDuplicateEnrollment
    @CourseId INT,
    @TraineeId INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Enrollments WHERE CourseId = @CourseId AND TraineeId = @TraineeId)
        SELECT 1 AS IsExists;
    ELSE
        SELECT 0 AS IsExists;
END;
go


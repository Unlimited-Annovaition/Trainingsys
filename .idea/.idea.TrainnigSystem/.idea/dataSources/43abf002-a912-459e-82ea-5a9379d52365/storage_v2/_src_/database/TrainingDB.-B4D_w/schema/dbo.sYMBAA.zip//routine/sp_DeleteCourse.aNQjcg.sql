CREATE PROCEDURE sp_DeleteCourse
@CourseId INT
AS
BEGIN
    DELETE FROM Courses WHERE CourseId = @CourseId;
END;
go


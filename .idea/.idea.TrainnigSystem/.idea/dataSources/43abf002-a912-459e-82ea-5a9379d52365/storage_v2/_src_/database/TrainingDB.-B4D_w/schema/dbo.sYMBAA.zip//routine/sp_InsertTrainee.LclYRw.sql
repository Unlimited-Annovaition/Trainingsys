CREATE PROCEDURE sp_InsertTrainee
    @FullName NVARCHAR(100),
    @PhoneNumber NVARCHAR(20),
    @UserId INT
AS
BEGIN
    INSERT INTO Trainees (FullName, PhoneNumber, UserId)
    VALUES (@FullName, @PhoneNumber, @UserId);
END;
go


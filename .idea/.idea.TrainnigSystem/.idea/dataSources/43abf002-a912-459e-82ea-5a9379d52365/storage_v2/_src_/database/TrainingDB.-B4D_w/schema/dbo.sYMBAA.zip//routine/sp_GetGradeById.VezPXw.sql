CREATE PROCEDURE sp_GetGradeById
@GradeId INT
AS
BEGIN
    SELECT * FROM Grades WHERE GradeId = @GradeId;
END;
go


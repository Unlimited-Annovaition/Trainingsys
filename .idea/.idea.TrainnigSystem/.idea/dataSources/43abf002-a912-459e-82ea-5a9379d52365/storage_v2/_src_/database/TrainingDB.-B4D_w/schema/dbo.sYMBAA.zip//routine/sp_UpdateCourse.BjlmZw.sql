CREATE PROCEDURE sp_UpdateCourse
    @CourseId INT,
    @Title NVARCHAR(150),
    @Description NVARCHAR(MAX),
    @Capacity INT,
    @StartDate DATE,
    @EndDate DATE,
    @TrainerId INT = NULL
AS
BEGIN
    UPDATE Courses
    SET Title = @Title,
        Description = @Description,
        Capacity = @Capacity,
        StartDate = @StartDate,
        EndDate = @EndDate,
        TrainerId = @TrainerId
    WHERE CourseId = @CourseId;
END;
go


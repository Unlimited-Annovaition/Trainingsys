CREATE PROCEDURE sp_GetTrainerById
@TrainerId INT
AS
BEGIN
    SELECT * FROM Trainers WHERE TrainerId = @TrainerId;
END;
go


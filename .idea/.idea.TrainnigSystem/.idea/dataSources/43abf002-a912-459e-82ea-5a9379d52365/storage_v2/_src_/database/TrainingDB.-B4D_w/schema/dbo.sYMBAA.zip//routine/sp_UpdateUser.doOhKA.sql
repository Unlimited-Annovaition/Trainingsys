CREATE PROCEDURE sp_UpdateUser
    @UserId INT,
    @Username NVARCHAR(100),
    @PasswordHash NVARCHAR(MAX),
    @Email NVARCHAR(100),
    @RoleId INT
AS
BEGIN
    UPDATE Users
    SET Username = @Username, PasswordHash = @PasswordHash, Email = @Email, RoleId = @RoleId
    WHERE UserId = @UserId;
END;
go


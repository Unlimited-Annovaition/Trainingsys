CREATE PROCEDURE sp_GetAllTrainees
AS
    Begin 
    SELECT 
        T.TraineeID,
        T.FullName,
        T.PhoneNumber,
        U.Email
        from Trainees T 
        INNER JOIN USERS U on T.UserId =U.UserID
end;
go

